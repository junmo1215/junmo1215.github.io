#include <iostream>
#include <iomanip>

#include <google/protobuf/util/json_util.h>

#include "proto/testData.pb.h"

using namespace std;

enum PrintFlag {
    PrintFlagBin = 1,
    PrintFlagHex = 2,
    PrintFlagChar = 4
};

// int g_printFlag = PrintFlagBin | PrintFlagHex | PrintFlagChar;

static const char g_asciiChar[129] = 
"................"
"................"
" !\"#$%&,()*+,-./"
"0123456789:;<=>?"
"@ABCDEFGHIJKLMNO"
"PQRSTUVWXYZ[\\]^_"
"`abcdefghijklmno"
"pqrstuvwxyz{|}`.";

string PbToJson(const google::protobuf::Message &pb) {
    string jsonStr;
    google::protobuf::util::MessageToJsonString(pb, &jsonStr);
    return jsonStr;
}

void debugPrint(const char *buffer, size_t size, int printFlag) {
    static const int nBatchSize = 8;
    size_t index = 0;
    while (index < size) {
        // 二进制显示
        if (printFlag & PrintFlagBin) {
            int remain = 0;
            for (int i = 0; i < nBatchSize; i++) {
                if (index + i >= size) {
                    remain = index + nBatchSize - size;
                    break;
                }
                unsigned char* address = (unsigned char*) (buffer + index + i);
                
                for (int j = 7; j >= 0; j--) {
                    unsigned char byte = (*address >> j) & 1;
                    printf("%u", byte);
                }
                
                printf(" ");
            }

            
            while (remain-- > 0) {
                printf("         ");
            }

            printf("    ");
        }

        // 十六进制显示
        if (printFlag & PrintFlagHex) {
            int remain = 0;
            for (int i = 0; i < nBatchSize; i++) {
                if (index + i >= size) {
                    remain = index + nBatchSize - size;
                    break;
                }
                unsigned char* address = (unsigned char*) (buffer + index + i);
                printf("%.2X ", *address);
            }

            while (remain-- > 0) {
                printf("   ");
            }

            printf("    ");
        }

        // ascii码显示
        if (printFlag & PrintFlagChar) {
            for (int i = 0; i < nBatchSize; i++) {
                if (index + i >= size) break;
                unsigned char* address = (unsigned char*) (buffer + index + i);
                printf("%c", g_asciiChar[*address]);
            }

            // cout << "\t";
        }

        printf("\n");
        index += nBatchSize;
    }
}

void encodeAndShow(const google::protobuf::Message &message) {
    size_t size = message.ByteSizeLong();
    char *buffer = new char[size];
    message.SerializeToArray(buffer, size);

    cout << "====================================" << endl;
    cout << "pb: " << PbToJson(message) << "\t size: " << size << endl;
    debugPrint(buffer, size, PrintFlagBin | PrintFlagHex | PrintFlagChar);
    cout << "====================================" << endl << endl;
}

// 单个字符串
void test1() {
    testData::Test1 test1;
    test1.set_s1("");
    encodeAndShow(test1);

    test1.set_s1("abcd");
    encodeAndShow(test1);

    test1.set_s1("AAAAAAAA");
    encodeAndShow(test1);
}

// 单个u32_t
void test2() {
    testData::Test2 test2;
    test2.set_i1(0);
    encodeAndShow(test2);

    test2.set_i1(10);
    encodeAndShow(test2);

    test2.set_i1(12345);
    encodeAndShow(test2);

    test2.set_i1(0xFFFFFFFF);encodeAndShow(test2);
    test2.set_i1(0xFFEECC88);encodeAndShow(test2);
    test2.set_i1(0b11110000);encodeAndShow(test2);
    test2.set_i1(0b00001111);encodeAndShow(test2);
}

void test3() {
    testData::Test3 test3;
    
    test3.set_fi1(0xFFFFFFFFFFFFFFFF);encodeAndShow(test3);
    test3.set_fi1(0x0);encodeAndShow(test3);
    test3.set_fi1(0xFF);encodeAndShow(test3);
    test3.set_fi1(0xFF00CC);encodeAndShow(test3);
}

void test4() {
    testData::Test4 test4;
    
    test4.set_fi1(0xFFFFFFFFFFFFFFFF);
    test4.set_fi2(0xFFFFFFFFFFFFFFFF);
    encodeAndShow(test4);

    test4.set_fi1(0x1234567890ABCDEF);
    test4.set_fi2(0x1234567890ABCDEF);
    encodeAndShow(test4);
}

void test5() {
    testData::Test5 test5;

    for (int i = 2; i >= -2; i--) {
        test5.set_i1(i);
        test5.set_i2(i);
        test5.set_i3(i);
        encodeAndShow(test5);
    }

    test5.set_i1(0x7FFFFFFF * -1);
    test5.set_i2(0);
    test5.set_i3(0);
    encodeAndShow(test5);
}

void test6() {
    vector<double> dTestCase = { 1, 123, 3.14159, -123, 0.001 };

    for (double dTest : dTestCase) {
        testData::Test6 test6;
        test6.set_d1(dTest);
        size_t size = test6.ByteSizeLong();
        char *buffer = new char[size];
        test6.SerializeToArray(buffer, size);

        // 将原始的值在内存中的内容打印出来，跟PB编码后的部分（去掉类型）进行比较
        cout << "====================================" << endl;
        cout << "dTest" << dTest << endl;
        cout << "PB encode:      ";
        debugPrint(buffer + 1, sizeof(double), PrintFlagBin | PrintFlagHex);
        cout << "Data in memory: ";
        debugPrint((char*)(&dTest), sizeof(double), PrintFlagBin | PrintFlagHex);
    }
}

void test7() {
    testData::Test7 test7;
    test7.set_requiredfield(0xFFFFFFFF);
    encodeAndShow(test7);

    test7.set_optionalfield(0x00);
    encodeAndShow(test7);

    test7.add_repeatedfield(0x00);
    encodeAndShow(test7);
    test7.add_repeatedfield(0xFFFFFFFF);
    encodeAndShow(test7);
}

void test8() {
    testData::Test8 test8;

    test8.set_i1(0xFF);
    test8.set_i2(0xFF);
    test8.set_i3(0xFF);
    test8.set_i4(0xFF);
    test8.set_i5(0xFF);
    encodeAndShow(test8);
}

// void test2() {
//     testData::SimpleData simpleData;
//     simpleData.set_sstr("abcde");
//     simpleData.set_nnum(0x0);
//     simpleData.set_ddouble(1);

//     size_t size = simpleData.ByteSizeLong();
//     char *buffer = new char[size];
//     simpleData.SerializeToArray(buffer, size);

//     cout << "====================================" << endl;
//     cout << "pb: " << PbToJson(simpleData) << "\t size: " << size << endl;
//     debugPrint(buffer, size);
//     cout << "====================================" << endl << endl;
// }

int main() {
    test8();
    return 0;
}