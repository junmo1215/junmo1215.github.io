#include <iostream>
#include <string>

#include "proto/cmdRegister.pb.h"
#include "../include/nlohmann/json.hpp"

#include <sys/time.h>

#define BUFF_SIZE 1024
#define TEST_COUNT 1000000

using namespace std;
using json = nlohmann::json;

size_t TestBin(const string &name, int age, char *buffer) {
    size_t offset = 0;

    size_t size = name.size();
    memcpy(buffer + offset, name.c_str(), size);
    offset += size;

    size = sizeof(int);
    memcpy(buffer + offset, &age, size);
    offset += size;
    
    return offset;
}

size_t TestNative(const string &name, int age, char *buffer) {
    string encodeStr = name + "|" + to_string(age);
    strcpy(buffer, encodeStr.c_str());
    return encodeStr.size();
}

size_t TestJson(const string &name, int age, char *buffer) {
    json jsonObj;
    jsonObj["name"] = name;
    jsonObj["age"] = age;
    string encodeStr = jsonObj.dump();
    strcpy(buffer, encodeStr.c_str());
    return encodeStr.size();
}

size_t TestProtobuf(const string &name, int age, char *buffer) {
    cmdRegister::Request request;
    request.set_name(name);
    request.set_age(age);

    size_t size = request.ByteSizeLong();
    request.SerializeToArray(buffer, size);
    return size;
}

void PrintResult(const string &testName, timeval begin, timeval end, size_t size) {
    double diff = end.tv_sec - begin.tv_sec + (end.tv_usec - begin.tv_usec) * 1.0 / 1000000;
    cout << testName << ":\ttime span: " << diff << ", size: " << size << endl;
}

int main() {
    char buffer[BUFF_SIZE];
    size_t totalSize;
    timeval begin, end;

    gettimeofday(&begin, 0);
    totalSize = 0;
    for (int i = 0; i < TEST_COUNT; i++) {
        totalSize += TestBin("alice", 10, buffer);
    }
    gettimeofday(&end, 0);
    PrintResult("TestBin", begin, end, totalSize / TEST_COUNT);


    gettimeofday(&begin, 0);
    totalSize = 0;
    for (int i = 0; i < TEST_COUNT; i++) {
        totalSize += TestNative("alice", 10, buffer);
    }
    gettimeofday(&end, 0);
    PrintResult("TestNative", begin, end, totalSize / TEST_COUNT);


    gettimeofday(&begin, 0);
    totalSize = 0;
    for (int i = 0; i < TEST_COUNT; i++) {
        totalSize += TestJson("alice", 10, buffer);
    }
    gettimeofday(&end, 0);
    PrintResult("TestJson", begin, end, totalSize / TEST_COUNT);


    gettimeofday(&begin, 0);
    totalSize = 0;
    for (int i = 0; i < TEST_COUNT; i++) {
        totalSize += TestProtobuf("alice", 10, buffer);
    }
    gettimeofday(&end, 0);
    PrintResult("TestProtobuf",begin, end, totalSize / TEST_COUNT);
}