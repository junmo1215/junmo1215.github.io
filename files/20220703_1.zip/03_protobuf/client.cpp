#include <iostream>
#include <string>

#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#include <google/protobuf/util/json_util.h>
#include "proto/cmdRegister.pb.h"

#define BUFF_SIZE 1024
#define IP "127.0.0.1"
#define PORT 6666

using namespace std;

void Register(string name, int age) {
    int sock = socket(AF_INET, SOCK_STREAM, 0);

    struct sockaddr_in servaddr;
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = inet_addr(IP);
    servaddr.sin_port = htons(PORT);
    connect(sock, (struct sockaddr*)&servaddr, sizeof(servaddr));

    cmdRegister::Request request;
    request.set_name(name);
    request.set_age(age);
    string sendMsg = request.SerializeAsString();

    send(sock, sendMsg.c_str(), sendMsg.size(), 0);
    string jsonStr;
    google::protobuf::util::MessageToJsonString(request, &jsonStr);
    cout << "<<< " << jsonStr << endl;

    char buffer[BUFF_SIZE];
    size_t recvSize = recv(sock, buffer, sizeof(buffer), 0);
    buffer[recvSize] = 0;
    string recvMsg(buffer);

    cmdRegister::Response response;
    response.ParseFromString(recvMsg);
    jsonStr = "";
    google::protobuf::util::MessageToJsonString(response, &jsonStr);
    cout << ">>> " << jsonStr << endl;
    int totalUserNum = response.totalusernum();

    cout << "After user[name=" << name << "] register. "
        << "Total user num is " << totalUserNum << endl;
    cout << endl;

    close(sock);
}

int main(){
    Register("alice", 10);
    return 0;
}