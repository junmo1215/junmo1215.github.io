#include <iostream>
#include <string>

#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#include <google/protobuf/util/json_util.h>
#include "proto/cmdRegister.pb.h"

#define BUFF_SIZE 1024
#define IP "127.0.0.1"
#define PORT 6666

using namespace std;

void ListenHelloAndReply() {
    int sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

    struct sockaddr_in servaddr;
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = inet_addr(IP);
    servaddr.sin_port = htons(PORT);
    bind(sock, (struct sockaddr*)&servaddr, sizeof(servaddr));
    listen(sock, 0);

    int totalUserNum = 0;

    while (true) {
        struct sockaddr_in client_addr;
        socklen_t client_size = sizeof(client_addr);
        int client_sock = accept(sock, (struct sockaddr*)&client_addr, &client_size);

        char buffer[BUFF_SIZE];
        size_t recvSize = recv(client_sock, buffer, sizeof(buffer), 0);
        buffer[recvSize] = 0;
        string recvMsg(buffer);
        // cout << ">>> " << recvMsg << endl;

        cmdRegister::Request request;
        request.ParseFromString(recvMsg);
        string jsonStr;
        google::protobuf::util::MessageToJsonString(request, &jsonStr);
        cout << ">>> " << jsonStr << endl;

        string name = request.name();
        int age = request.age();

        totalUserNum++;
        cout << "Recv register info name: " << name << " age:" << age
            << ". Total user num is " << totalUserNum << endl;

        cmdRegister::Response response;
        response.set_name(name);
        response.set_totalusernum(totalUserNum);
        string sendMsg = response.SerializeAsString();

        send(client_sock, sendMsg.c_str(), sendMsg.size(), 0);
        jsonStr = "";
        google::protobuf::util::MessageToJsonString(response, &jsonStr);
        cout << "<<< " << jsonStr << endl;
        cout << endl;

        close(client_sock);
    }

    close(sock);
}

int main() {
    ListenHelloAndReply();
    
    return 0;
}