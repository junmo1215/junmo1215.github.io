#include <iostream>
#include <string>

#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define BUFF_SIZE 1024
#define IP "127.0.0.1"
#define PORT 6666

using namespace std;

void Register(string name, int age) {
    int sock = socket(AF_INET, SOCK_STREAM, 0);

    struct sockaddr_in servaddr;
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = inet_addr(IP);
    servaddr.sin_port = htons(PORT);
    connect(sock, (struct sockaddr*)&servaddr, sizeof(servaddr));

    string sendMsg = name + "|" + to_string(age);

    send(sock, sendMsg.c_str(), sendMsg.size(), 0);
    cout << "<<< " << sendMsg << endl;

    char buffer[BUFF_SIZE];
    size_t recvSize = recv(sock, buffer, sizeof(buffer), 0);
    buffer[recvSize] = 0;
    string recvMsg(buffer);
    cout << ">>> " << recvMsg << endl;

    int splitIndex = recvMsg.find("|");
    int totalUserNum = stoi(recvMsg.substr(splitIndex + 1));

    cout << "After user[name=" << name << "] register. "
        << "Total user num is " << totalUserNum << endl;
    cout << endl;

    close(sock);
}

int main(){
    Register("alice", 10);
    return 0;
}