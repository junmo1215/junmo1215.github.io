#include <iostream>
#include <string>

#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define BUFF_SIZE 1024
#define IP "127.0.0.1"
#define PORT 6666

using namespace std;

void ListenRegister() {
    int sock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

    struct sockaddr_in servaddr;
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
    servaddr.sin_port = htons(PORT);
    bind(sock, (struct sockaddr*)&servaddr, sizeof(servaddr));
    listen(sock, 0);

    int totalUserNum = 0;

    while (true) {
        struct sockaddr_in client_addr;
        socklen_t client_size = sizeof(client_addr);
        int client_sock = accept(sock, (struct sockaddr*)&client_addr, &client_size);

        char buffer[BUFF_SIZE];
        size_t recvSize = recv(client_sock, buffer, sizeof(buffer), 0);
        buffer[recvSize] = 0;
        string recvMsg(buffer);
        cout << ">>> " << recvMsg << endl;

        int splitIndex = recvMsg.find("|");
        string name = recvMsg.substr(0, splitIndex);
        int age = stoi(recvMsg.substr(splitIndex + 1));

        totalUserNum++;
        cout << "Recv register info name: " << name << " age:" << age
            << ". Total user num is " << totalUserNum << endl;

        string sendMsg = name + "|" + to_string(totalUserNum);

        send(client_sock, sendMsg.c_str(), sendMsg.size(), 0);
        cout << "<<< " << sendMsg << endl;
        cout << endl;

        close(client_sock);
    }

    close(sock);
}

int main() {
    ListenRegister();
    
    return 0;
}